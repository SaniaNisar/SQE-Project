create
    definer = root@localhost procedure signupListener(IN LNameIn varchar(50), IN LPasswordIn varchar(50),
                                                      IN LEmailIn varchar(255), OUT status bit)
BEGIN 
    DECLARE listenerCount, emailCount INT;
    SELECT COUNT(*) INTO listenerCount FROM Listener WHERE Lname = LNameIn;
    SELECT COUNT(*) INTO emailCount FROM Listener WHERE LEmail = LEmailIn;
    IF listenerCount > 0 OR emailCount > 0 THEN
        SET status = false;
    ELSE
        INSERT INTO Listener(Lname, LPassword, LEmail) VALUES (LNameIn, LPasswordIn, LEmailIn);
        SET status = true;
    END IF;
END;

