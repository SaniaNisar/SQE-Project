create
    definer = root@localhost procedure signupArtist(IN ANameIn varchar(50), IN APasswordIn varchar(50),
                                                    IN AEmailIn varchar(255), IN ABioIn mediumtext, OUT status bit)
BEGIN 
    DECLARE artistCount, emailCount INT;
    SELECT COUNT(*) INTO artistCount FROM Artist WHERE AName = ANameIn;
    SELECT COUNT(*) INTO emailCount FROM Artist WHERE AEmail = AEmailIn;
    IF artistCount > 0 OR emailCount > 0 THEN
        SET status = false;
    ELSE
        INSERT INTO Artist(AName, APassword, AEmail, ABio) VALUES (ANameIn, APasswordIn, AEmailIn, ABioIn);
        SET status = true;
    END IF;
END;

