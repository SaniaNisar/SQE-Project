create
    definer = root@localhost procedure loginArtist(IN ANameIn varchar(50), IN APasswordIn varchar(50),
                                                   IN AEmailIn varchar(255), OUT status bit)
BEGIN
    DECLARE ArtistCount INT;
    SET ArtistCount = (SELECT COUNT(*) FROM Artist WHERE AName = ANameIn AND APassword = APasswordIn AND AEmail = AEmailIn);

    IF ArtistCount = 0 THEN
        SET status = false;
    ELSE
        SET status = true;
    END IF;
END;

