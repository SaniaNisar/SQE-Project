create
    definer = root@localhost procedure loginListener(IN LNameIn varchar(50), IN LPasswordIn varchar(50),
                                                     IN LEmailIn varchar(255), OUT status bit)
BEGIN
    DECLARE listenerCount INT;
    SET listenerCount = (SELECT COUNT(*) FROM Listener WHERE Lname = LNameIn AND LPassword = LPasswordIn AND LEmail = LEmailIn);

    IF listenerCount = 0 THEN
        SET status = false;
    ELSE
        SET status = true;
    END IF;
END;

