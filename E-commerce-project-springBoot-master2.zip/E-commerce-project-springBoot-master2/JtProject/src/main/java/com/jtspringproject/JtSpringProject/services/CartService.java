package com.jtspringproject.JtSpringProject.services;

import com.jtspringproject.JtSpringProject.dao.CartDao;
import com.jtspringproject.JtSpringProject.models.Cart;
import com.jtspringproject.JtSpringProject.models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private static CartDao cartDao;

    @Transactional
    public void addToCart(Cart cart, int productId, int quantity) {
        // Fetch the product from the database
        Product product = productService.getProduct(productId);

        if (product != null) {
            // Add the product to the cart
            cart.addCartItem(new CartItem(product, quantity));
        }
    }
    @Transactional
    public static List<Cart> getCarts() {
       return cartDao.getCarts();
    }

    @Transactional
    public Cart getCartById(int cartId) {
        return cartDao.getCartById(cartId);
    }

    @Transactional
    public void updateCart(Cart cart) {
        cartDao.updateCart(cart);
    }

    @Transactional
    public void deleteCart(Cart cart) {
        cartDao.deleteCart(cart);
    }

    @Transactional
    public void removeProductFromCart(int cartId, int productId) {
        cartDao.removeProductFromCart(cartId, productId);
    }
}
