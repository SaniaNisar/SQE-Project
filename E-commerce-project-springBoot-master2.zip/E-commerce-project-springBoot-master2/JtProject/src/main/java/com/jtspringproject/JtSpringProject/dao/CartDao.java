package com.jtspringproject.JtSpringProject.dao;

import com.jtspringproject.JtSpringProject.models.Cart;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class CartDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public Cart addCart(Cart cart) {
        entityManager.persist(cart);
        return cart;
    }

    @Transactional
    public List<Cart> getCarts() {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Cart> criteria = builder.createQuery(Cart.class);
        Root<Cart> root = criteria.from(Cart.class);
        criteria.select(root);
        return entityManager.createQuery(criteria).getResultList();
    }

    @Transactional
    public Cart getCartById(int cartId) {
        return entityManager.find(Cart.class, cartId);
    }

    @Transactional
    public void updateCart(Cart cart) {
        entityManager.merge(cart);
    }

    @Transactional
    public void deleteCart(Cart cart) {
        entityManager.remove(cart);
    }

    @Transactional
    public void removeProductFromCart(int cartId, int productId) {
        Cart cart = getCartById(cartId);
        if (cart != null) {
            cart.removeProduct(productId); // Assuming there's a method to remove a product by ID in the Cart entity
            updateCart(cart);
        }
    }
}
