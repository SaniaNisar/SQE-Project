package com.jtspringproject.JtSpringProject;

import com.jtspringproject.JtSpringProject.controller.UserController;
import com.jtspringproject.JtSpringProject.models.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.jtspringproject.JtSpringProject.services.userService;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
public class UserControllerTest {

    private MockMvc mockMvc;



    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    @Test
    public void testUserLogin() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("userLogin"));
    }

    @Test
    public void testUserLoginValidateSuccess() throws Exception {
        User mockUser = new User();
        mockUser.setUsername("testUser");
        mockUser.setPassword("testPass");
        when(userService.checkLogin("testUser", "testPass")).thenReturn(mockUser);

        mockMvc.perform(post("/userloginvalidate")
                        .param("username", "testUser")
                        .param("password", "testPass"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"))
                .andExpect(model().attributeExists("user"));
    }

    @Test
    public void testUserLoginValidateFailure() throws Exception {
        when(userService.checkLogin("invalidUser", "invalidPass")).thenReturn(null);

        mockMvc.perform(post("/userloginvalidate")
                        .param("username", "invalidUser")
                        .param("password", "invalidPass"))
                .andExpect(status().isOk())
                .andExpect(view().name("userLogin"))
                .andExpect(model().attribute("msg", "Invalid username or password"));
    }
}
