package com.jtspringproject.JtSpringProject.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jtspringproject.JtSpringProject.models.User;

import java.util.List;

@Repository
public class userDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Transactional
	public List<User> getAllUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		return session.createQuery("from CUSTOMER", User.class).list();
	}

	@Transactional
	public User saveUser(User user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
		return user;
	}

	@Transactional
	public User getUserById(int userId) {
		Session session = this.sessionFactory.getCurrentSession();
		return session.get(User.class, userId);
	}

	@Transactional
	public User getUser(String username, String password) {
		Query<User> query = sessionFactory.getCurrentSession().createQuery("from CUSTOMER where username = :username", User.class);
		query.setParameter("username", username);

		try {
			return query.getSingleResult();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return new User();
		}
	}
}
