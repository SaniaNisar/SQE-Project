package com.jtspringproject.JtSpringProject.services;

import com.jtspringproject.JtSpringProject.dao.userDao;
import com.jtspringproject.JtSpringProject.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class userService {

	@Autowired
	private userDao userDao;

	@Transactional
	public List<User> getUsers() {
		return this.userDao.getAllUsers() ;
	}

	@Transactional
	public User addUser(User user) {
		return this.userDao.saveUser(user);
	}

	@Transactional
	public User updateUser(User user) {
		return this.userDao.saveUser(user);
	}

	@Transactional
	public void deleteUser(int userId) {
		this.userDao.deleteUser(userId);
	}

	@Transactional
	public User getUserById(int userId) {
		return this.userDao.getUserById(userId);
	}

	@Transactional
	public User checkLogin(String username, String password) {
		return this.userDao.getUser(username, password);
	}
}
